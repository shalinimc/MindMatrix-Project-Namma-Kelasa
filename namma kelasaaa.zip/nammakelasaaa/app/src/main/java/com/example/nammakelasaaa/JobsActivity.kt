package com.example.nammakelasaaa

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class JobsActivity : AppCompatActivity(), JobAdapter.OnJobClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jobs)

        val recyclerView = findViewById<RecyclerView>(R.id.allJobsRecyclerView)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = JobAdapter(JobRepository.getJobs(), this)

        bottomNav.selectedItemId = R.id.nav_jobs

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_jobs -> true
                R.id.nav_saved -> {
                    startActivity(Intent(this, SavedJobsActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    override fun onJobClick(job: JobModel) {
        val intent = Intent(this, JobDetailsActivity::class.java)
        intent.putExtra("JOB_DATA", job)
        startActivity(intent)
    }
}
