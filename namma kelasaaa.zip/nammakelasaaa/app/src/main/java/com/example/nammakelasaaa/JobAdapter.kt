package com.example.nammakelasaaa

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip

class JobAdapter(private var jobList: List<JobModel>, private val listener: OnJobClickListener) :
    RecyclerView.Adapter<JobAdapter.JobViewHolder>() {

    fun updateList(newList: List<JobModel>) {
        jobList = newList
        notifyDataSetChanged()
    }

    interface OnJobClickListener {
        fun onJobClick(job: JobModel)
    }

    class JobViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.jobTitle)
        val company: TextView = view.findViewById(R.id.jobCompany)
        val location: TextView = view.findViewById(R.id.jobLocation)
        val salary: TextView = view.findViewById(R.id.jobSalary)
        val typeChip: Chip = view.findViewById(R.id.jobTypeChip)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_job, parent, false)
        return JobViewHolder(view)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        val job = jobList[position]
        holder.title.text = job.title
        holder.company.text = job.company
        holder.location.text = job.location
        holder.salary.text = job.salary
        holder.typeChip.text = job.jobType

        holder.itemView.setOnClickListener {
            listener.onJobClick(job)
        }
    }

    override fun getItemCount() = jobList.size
}