package com.example.nammakelasaaa

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView

class SavedJobsActivity : AppCompatActivity(), JobAdapter.OnJobClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved_jobs)

        val recyclerView = findViewById<RecyclerView>(R.id.savedJobsRecyclerView)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)

        recyclerView.layoutManager = LinearLayoutManager(this)
        // For prototype, show first 3 jobs as saved
        val savedJobs = JobRepository.getJobs().take(3)
        recyclerView.adapter = JobAdapter(savedJobs, this)

        bottomNav.selectedItemId = R.id.nav_saved

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_jobs -> {
                    startActivity(Intent(this, JobsActivity::class.java))
                    finish()
                    true
                }
                R.id.nav_saved -> true
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    finish()
                    true
                }
                else -> false
            }
        }
    }

    override fun onJobClick(job: JobModel) {
        val intent = Intent(this, JobDetailsActivity::class.java)
        intent.putExtra("JOB_DATA", job)
        startActivity(intent)
    }
}
