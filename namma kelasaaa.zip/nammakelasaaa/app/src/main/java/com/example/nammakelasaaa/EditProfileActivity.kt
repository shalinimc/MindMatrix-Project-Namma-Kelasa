package com.example.nammakelasaaa

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class EditProfileActivity : AppCompatActivity() {

    private lateinit var profileImageView: ImageView

    private val getImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            profileImageView.setImageURI(it)
            Toast.makeText(this, "Photo updated locally!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val backBtn = findViewById<ImageButton>(R.id.backBtn)
        val saveBtn = findViewById<Button>(R.id.saveProfileBtn)
        val changePhotoBtn = findViewById<ImageView>(R.id.changePhotoBtn)
        profileImageView = findViewById(R.id.editProfileImage)

        backBtn.setOnClickListener {
            finish()
        }

        changePhotoBtn.setOnClickListener {
            getImage.launch("image/*")
        }

        saveBtn.setOnClickListener {
            // Prototype logic: show success message and go back
            Toast.makeText(this, "Profile Updated Successfully!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
