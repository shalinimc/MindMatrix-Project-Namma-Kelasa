package com.example.nammakelasaaa

object JobRepository {
    fun getJobs(): List<JobModel> {
        return listOf(
            // IT & Software
            JobModel("Android Developer", "Tech Solutions", "Whitefield, Bangalore", "₹45,000/mo", "Full Time", "9876543210", "Software development role focusing on Android apps using Kotlin and Jetpack Compose."),
            JobModel("Web Developer", "Digital Agency", "Indiranagar, Bangalore", "₹40,000/mo", "Full Time", "9876543211", "Software engineer for building web applications using React.js and Node.js."),
            JobModel("Graphic Designer", "Creative Studio", "Koramangala, Bangalore", "₹30,000/mo", "Full Time", "9876543212", "Visual designer for creating social media content and brand identity."),

            // Education
            JobModel("Math Teacher", "Global School", "Jayanagar, Bangalore", "₹35,000/mo", "Full Time", "9876543213", "Teaching role for high school students. Math and Science focus."),
            JobModel("Music Teacher", "Harmony Academy", "HSR Layout, Bangalore", "₹15,000/mo", "Part Time", "9876543214", "Music instructor for evening classes. Piano and Guitar focus."),

            // Office & Administration
            JobModel("Data Entry Operator", "Logistics Corp", "Electronic City, Bangalore", "₹18,000/mo", "Full Time", "9876543215", "Office role requiring accurate data entry and Excel management."),
            JobModel("Receptionist", "City Hotel", "MG Road, Bangalore", "₹22,000/mo", "Full Time", "9876543216", "Front desk reception and guest handling for city hotel."),
            JobModel("Accountant", "Finance Hub", "Malleshwaram, Bangalore", "₹35,000/mo", "Full Time", "9876543217", "Accounting role with mandatory Tally and GST filing experience."),

            // Sales & Retail
            JobModel("Sales Executive", "Fashion Hub", "Commercial Street, Bangalore", "₹20,000/mo", "Full Time", "9876543218", "Retail sales representative for fashion clothing brand."),
            JobModel("Marketing Manager", "Startup X", "Indiranagar, Bangalore", "₹60,000/mo", "Full Time", "9876543219", "Marketing and growth manager for digital startup."),

            // Skilled Services (Workers)
            JobModel("Electrician", "Power Pro", "Koramangala, Bangalore", "₹1200/day", "Daily", "9876543222", "Licensed electrician for home wiring and electrical repairs."),
            JobModel("Plumber", "Home Fixers", "Indiranagar, Bangalore", "₹800/day", "Daily", "9876543225", "Plumbing expert for leak fixing and pipe installation."),
            JobModel("Painter", "Color World", "Jayanagar, Bangalore", "₹1500/day", "Daily", "9876543224", "Professional painter for interior and exterior walls."),
            
            // Logistics & Delivery
            JobModel("Delivery Partner", "FastCart", "All Over Bangalore", "₹25,000/mo", "Contract", "9876543230", "Delivery role for packages and food items."),
            JobModel("Driver", "City Cabs", "Whitefield, Bangalore", "₹20,000/mo", "Full Time", "9876543231", "Driving role with valid commercial license."),

            // Others
            JobModel("Security Guard", "Safe Guard", "HSR Layout, Bangalore", "₹16,000/mo", "Full Time", "9876543235", "Security services for residential apartments and offices."),
            JobModel("Cook", "Tasty Bites", "Indiranagar, Bangalore", "₹15,000/mo", "Part Time", "9876543240", "Home cooking and food preparation services."),
            JobModel("Gardener", "Green Thumb", "Whitefield, Bangalore", "₹800/day", "Daily", "9876543245", "Gardening and lawn maintenance services.")
        )
    }
}
