package com.example.nammakelasaaa

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class ApplyJobActivity : AppCompatActivity() {

    private var selectedFileUri: Uri? = null
    private lateinit var fileNameText: TextView

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            selectedFileUri = result.data?.data
            fileNameText.text = selectedFileUri?.path?.split("/")?.last() ?: "File Selected"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apply_job)

        val nameInput = findViewById<TextInputEditText>(R.id.applyName)
        val expInput = findViewById<TextInputEditText>(R.id.applyExperience)
        val uploadBtn = findViewById<Button>(R.id.uploadResumeBtn)
        val submitBtn = findViewById<Button>(R.id.submitApplicationBtn)
        fileNameText = findViewById(R.id.fileNameText)

        uploadBtn.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.type = "application/pdf"
            filePickerLauncher.launch(intent)
        }

        submitBtn.setOnClickListener {
            val name = nameInput.text.toString()
            val exp = expInput.text.toString()

            if (name.isEmpty() || exp.isEmpty() || selectedFileUri == null) {
                Toast.makeText(this, "Please fill all fields and upload resume", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // In a real app, you would upload to Firebase Storage and Save to Firestore
            Toast.makeText(this, "Application Submitted Successfully!", Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
