package com.example.nammakelasaaa

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class JobDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_job_details)

        val job = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("JOB_DATA", JobModel::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("JOB_DATA") as? JobModel
        }

        val title = findViewById<TextView>(R.id.detailTitle)
        val company = findViewById<TextView>(R.id.detailCompany)
        val location = findViewById<TextView>(R.id.detailLocation)
        val salary = findViewById<TextView>(R.id.detailSalary)
        val desc = findViewById<TextView>(R.id.detailDescription)
        val reqs = findViewById<TextView>(R.id.detailRequirements)
        val callBtn = findViewById<Button>(R.id.callBtn)
        val msgBtn = findViewById<Button>(R.id.msgBtn)
        val applyBtn = findViewById<Button>(R.id.applyBtn)

        job?.let {
            title.text = it.title
            company.text = it.company
            location.text = it.location
            salary.text = it.salary
            desc.text = it.description
            reqs.text = it.requirements

            callBtn.setOnClickListener { _ ->
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:${it.phone}")
                startActivity(intent)
            }

            msgBtn.setOnClickListener { _ ->
                val uri = Uri.parse("smsto:${it.phone}")
                val intent = Intent(Intent.ACTION_SENDTO, uri)
                intent.putExtra("sms_body", "Hello, I am interested in your ${it.title} service.")
                startActivity(intent)
            }

            applyBtn.setOnClickListener { _ ->
                startActivity(Intent(this, ApplyJobActivity::class.java))
            }
        }
    }
}
