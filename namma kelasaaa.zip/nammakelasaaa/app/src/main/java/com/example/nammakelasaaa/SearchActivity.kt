package com.example.nammakelasaaa

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText

class SearchActivity : AppCompatActivity(), JobAdapter.OnJobClickListener {

    private lateinit var adapter: JobAdapter
    private val allJobs = JobRepository.getJobs()
    private var displayJobs = allJobs.toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        val queryInput = findViewById<TextInputEditText>(R.id.searchQueryInput)
        val locationInput = findViewById<TextInputEditText>(R.id.filterLocationInput)
        val salaryInput = findViewById<TextInputEditText>(R.id.filterSalaryInput)
        val applyBtn = findViewById<Button>(R.id.applyFiltersBtn)
        val recyclerView = findViewById<RecyclerView>(R.id.searchResultsRecyclerView)

        adapter = JobAdapter(displayJobs, this)
        recyclerView.adapter = adapter

        // Handle intent extras from MainActivity
        val intentSkill = intent.getStringExtra("SKILL")
        val intentLocation = intent.getStringExtra("LOCATION")
        
        if (intentSkill != null || intentLocation != null) {
            queryInput.setText(intentSkill)
            locationInput.setText(intentLocation)
            filterResults(intentSkill ?: "", intentLocation ?: "", 0)
        }

        applyBtn.setOnClickListener {
            val query = queryInput.text.toString().trim()
            val location = locationInput.text.toString().trim()
            val minSalary = salaryInput.text.toString().toIntOrNull() ?: 0

            filterResults(query, location, minSalary)
        }
    }

    private fun filterResults(query: String, location: String, minSalary: Int) {
        val filtered = allJobs.filter { job ->
            val matchesQuery = query.isEmpty() || 
                    job.title.contains(query, ignoreCase = true) || 
                    job.company.contains(query, ignoreCase = true) ||
                    job.description.contains(query, ignoreCase = true)
            
            val matchesLocation = location.isEmpty() || job.location.contains(location, ignoreCase = true)
            
            // Extract numeric salary for comparison (e.g. "₹1200/day" -> 1200)
            val jobSalaryNum = job.salary.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
            val matchesSalary = minSalary == 0 || jobSalaryNum >= minSalary

            matchesQuery && matchesLocation && matchesSalary
        }
        
        adapter.updateList(filtered)
        
        val emptyStateText = findViewById<android.widget.TextView>(R.id.emptyStateText)
        if (filtered.isEmpty()) {
            emptyStateText.visibility = android.view.View.VISIBLE
        } else {
            emptyStateText.visibility = android.view.View.GONE
        }
    }

    override fun onJobClick(job: JobModel) {
        val intent = Intent(this, JobDetailsActivity::class.java)
        intent.putExtra("JOB_DATA", job)
        startActivity(intent)
    }
}
