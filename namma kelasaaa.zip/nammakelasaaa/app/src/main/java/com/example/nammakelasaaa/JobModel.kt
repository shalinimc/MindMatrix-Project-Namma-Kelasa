package com.example.nammakelasaaa

import java.io.Serializable

data class JobModel(
    val title: String,
    val company: String,
    val location: String,
    val salary: String,
    val jobType: String,
    val phone: String = "9876543210", // Default phone for prototype
    val description: String = "Reliable service with 5+ years of experience.",
    val requirements: String = "• Valid ID proof\n• Tools required for work\n• Punctuality"
) : Serializable
