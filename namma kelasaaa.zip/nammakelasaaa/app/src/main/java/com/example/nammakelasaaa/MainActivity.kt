package com.example.nammakelasaaa

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.children
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity(), JobAdapter.OnJobClickListener {

    private lateinit var jobAdapter: JobAdapter
    private val allJobs = JobRepository.getJobs()
    private var filteredJobs = allJobs.toMutableList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.jobRecyclerView)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        val skillInput = findViewById<TextInputEditText>(R.id.skillInput)
        val locationInput = findViewById<TextInputEditText>(R.id.locationInput)
        val findJobsBtn = findViewById<Button>(R.id.findJobsBtn)
        val chipGroupSuggestions = findViewById<ChipGroup>(R.id.chipGroupSuggestions)

        recyclerView.layoutManager = LinearLayoutManager(this)
        jobAdapter = JobAdapter(filteredJobs, this)
        recyclerView.adapter = jobAdapter

        findJobsBtn.setOnClickListener {
            val skill = skillInput.text.toString().trim()
            val location = locationInput.text.toString().trim()
            
            val intent = Intent(this, SearchActivity::class.java)
            intent.putExtra("SKILL", skill)
            intent.putExtra("LOCATION", location)
            startActivity(intent)
        }

        chipGroupSuggestions.children.forEach { view ->
            if (view is Chip) {
                view.setOnClickListener {
                    val suggestion = view.text.toString()
                    val intent = Intent(this, SearchActivity::class.java)
                    intent.putExtra("SKILL", suggestion)
                    startActivity(intent)
                }
            }
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_jobs -> {
                    startActivity(Intent(this, JobsActivity::class.java))
                    true
                }
                R.id.nav_saved -> {
                    startActivity(Intent(this, SavedJobsActivity::class.java))
                    true
                }
                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onJobClick(job: JobModel) {
        val intent = Intent(this, JobDetailsActivity::class.java)
        intent.putExtra("JOB_DATA", job)
        startActivity(intent)
    }
}
